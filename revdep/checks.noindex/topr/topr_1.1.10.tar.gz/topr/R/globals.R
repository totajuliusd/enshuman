
utils::globalVariables(c(
  "POS", "log10p", "Gene_Symbol", "x1", "x2", "y1", "y2", "xpos", "ypos", "label","chrom","gene_start","gene_end","biotype","CHROM","CHR","chr","pos","BP",
  "rsid","rsID","rsId","rsName","SNP","snp","E2","E1","gene_symbol","exons","genes_coords","xmin","xmax","P","REF1","REF2","ALT1","ALT2","y_P","y_Effect","x_Effect",
  "C1","C2","C1_x","C2_x","ALT1tmp","ALT2tmp","y","level_count","tmp","REF","ALT","V1","V2","m","BETA","ID_tmp","P1","ID","POS_orig","pm","snpset1","REF2tmp","ID_tmp",
  "df","label_size","vline","val","offset","color","R2"
))


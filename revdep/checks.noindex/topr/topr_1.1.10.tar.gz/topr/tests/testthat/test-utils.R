test_that("get_gene_coords works", {
   get_gene_coords("IL23R")
})


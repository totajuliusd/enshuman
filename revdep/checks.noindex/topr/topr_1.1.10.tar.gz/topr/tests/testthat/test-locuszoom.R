test_that("locuszoom works", {
  expect_no_error(locuszoom(R2_CD_UKBB))
})

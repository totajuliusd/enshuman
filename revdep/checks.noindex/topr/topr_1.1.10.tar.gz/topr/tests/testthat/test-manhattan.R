test_that("basic manhattan works", {
  expect_error(manhattan(CD_UKBB), NA)
})
